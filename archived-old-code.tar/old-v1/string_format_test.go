// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package tppi

import (
	"reflect"
	"testing"
)

func TestStringFormat_Encode(t *testing.T) {
	type args struct {
		arg any
	}
	tests := []struct {
		name    string
		options []StringFormatOptions
		args    args
		wantS   string
		wantErr bool
	}{
		{
			name: "Encode String with quotes",
			options: []StringFormatOptions{
				WithStringFormat("%q"),
			},
			args: args{
				arg: "Hari Aum",
			},
			wantS: "\"Hari Aum\"",
		},
		{
			name:    "Encode normal Number",
			options: []StringFormatOptions{},
			args: args{
				arg: 0x3508,
			},
			wantS: "13576",
		},
		{
			name:    "Encode normal Boolean",
			options: []StringFormatOptions{},
			args: args{
				arg: true,
			},
			wantS: "true",
		},
		{
			name: "Encode Number in Hex",
			options: []StringFormatOptions{
				WithStringFormat("%X"),
			},
			args: args{
				arg: 0x3508,
			},
			wantS: "3508",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			sf := NewStringFormat(tt.options...)
			gotS, err := sf.Encode(tt.args.arg)
			if (err != nil) != tt.wantErr {
				t.Errorf("StringFormat.Encode() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if gotS != tt.wantS {
				t.Errorf("StringFormat.Encode() = %v, want %v", gotS, tt.wantS)
			}
		})
	}
}

func TestStringFormat_Decode(t *testing.T) {
	type args struct {
		arg any
		s   string
	}
	tests := []struct {
		name    string
		options []StringFormatOptions
		args    args
		wantVal any
		wantErr bool
	}{
		{
			name: "Positive Decode Quoted String",
			options: []StringFormatOptions{
				WithStringFormat("%q"),
			},
			args: args{
				arg: new(string),
				s:   "\"Hari Aum\"",
			},
			wantVal: func() *string {
				s := "Hari Aum"
				return &s
			}(),
		},
		{
			name:    "Positive Decode normal Number",
			options: []StringFormatOptions{},
			args: args{
				s:   "13576",
				arg: new(uint32),
			},
			wantVal: func() *uint32 {
				v := uint32(0x3508)
				return &v
			}(),
		},
		{
			name:    "Positive Decode normal bool",
			options: []StringFormatOptions{},
			args: args{
				s:   "true",
				arg: new(bool),
			},
			wantVal: func() *bool {
				v := true
				return &v
			}(),
		},
		{
			name: "Positive Decode Number in Hex Format",
			options: []StringFormatOptions{
				WithStringFormat("%X"),
			},
			args: args{
				s:   "3508",
				arg: new(uint32),
			},
			wantVal: func() *uint32 {
				v := uint32(0x3508)
				return &v
			}(),
		},
		{
			name:    "Negative Error in type",
			options: []StringFormatOptions{},
			args: args{
				s:   "Help",
				arg: new(uint32),
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			sf := NewStringFormat(tt.options...)
			gotVal, err := sf.Decode(tt.args.arg, tt.args.s)
			if (err != nil) != tt.wantErr {
				t.Errorf("StringFormat.Decode() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotVal, tt.wantVal) && !tt.wantErr {
				t.Errorf("HexFormat.decode() = %v, want %v", gotVal, tt.wantVal)
			}
		})
	}
}

func TestStringFormat_other(t *testing.T) {
	sf := NewStringFormat()
	if s, ok := sf.(*StringFormat); ok && s.Mark() != stringFormatMark {
		t.Errorf("Error in NewStringFormat default format")
		return
	}
}
