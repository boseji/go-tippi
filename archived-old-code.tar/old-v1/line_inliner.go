// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package tppi

import (
	"fmt"
)

// Line type generates the Line Needed for the protocol with the necessary
// TPPI protocol safeguards.
type Line struct {
	parts           []string         // Raw contents
	joinRule        CollectionRule   // Rule to Create the Final line
	splitRule       SplittingRule    // Rule to Split and obtain contents
	stuffingRules   map[string]Rules // Stuffing Rules for the contents
	unStuffingRules map[string]Rules // UnStuffing Rules for the contents
}

// LineOptions helps to setup parameters for the Line for TPPI Protocol
type LineOptions func(*Line) *Line

// Add allows to add more contents to the Line following the
// protocol safeguards of TPPI Protocol.
// It implements the InLiner interface.
func (l *Line) Add(sa ...string) error {
	safe := make([]string, 0, len(l.parts)+len(sa))
	safe = append(safe, l.parts...)
	safe = append(safe, sa...)
	l.parts = safe
	return nil
}

// Contents returns the contents of the given line as a []string slice.
// It implements the InLiner interface.
func (l *Line) Contents() []string {
	return l.parts
}

// Process creates the formatted single line following the assembly
// as per the rules of TPPI Protocol.
// It implements the InLiner interface.
func (l *Line) Processed() (s string, err error) {
	if len(l.parts) == 0 {
		err = fmt.Errorf("unable to process as no contents in line")
		return
	}
	sa, err := RunRules(l.stuffingRules, l.parts...)
	if err != nil {
		err = fmt.Errorf("unable to process as stuffing rules failed - %v", err)
		return
	}
	// Join everything with Inline separator
	s, err = l.joinRule(sa...)
	if err != nil {
		err = fmt.Errorf("unable to process as joining rule failed - %v", err)
		return
	}
	return
}

// Decode Creates a collection contents based on the supplied combined string
// following the rules of TPPI Protocol.
// It implements the InLiner interface.
func (b *Line) Decode(s string) (err error) {
	sa, err := b.splitRule(s)
	if err != nil {
		err = fmt.Errorf("unable to decode as splitting rule failed - %v", err)
		return
	}
	sf, err := RunRules(b.unStuffingRules, sa...)
	if err != nil {
		err = fmt.Errorf("unable to decode as un-Stuffing rules failed - %v",
			err)
		return
	}
	b.parts = sf
	return
}

// Clear helps to clean up the line contents and prepare a fresh InLiner.
// It implements the InLiner interface.
func (b *Line) Clear() {
	b.parts = make([]string, 0, 1)
}

// WithLineJoin helps to add a CollectionRule for the Line to prepare
// a line with all the contents as per TPPI protocol.
func WithLineJoin(j CollectionRule) LineOptions {
	return func(l *Line) *Line {
		l.joinRule = j
		return l
	}
}

// WithLineSplit helps to add a SplittingRule for the Line to
// decode a line into a collection of contents as per TPPI protocol.
func WithLineSplit(s SplittingRule) LineOptions {
	return func(l *Line) *Line {
		l.splitRule = s
		return l
	}
}

// WithLineStuffing helps to add a named Stuffing rule for the Line to
// filter contents of the line as per TPPI protocol safe guards.
func WithLineStuffing(name string, f Rules) LineOptions {
	return func(l *Line) *Line {
		l.stuffingRules[name] = f
		return l
	}
}

// WithLineUnStuffing helps to add a named UnStuffing rule for the Line to
// restore the contents removing the TPPI protocol safe guards.
func WithLineUnStuffing(name string, f Rules) LineOptions {
	return func(l *Line) *Line {
		l.unStuffingRules[name] = f
		return l
	}
}

// defaultLine sets up the Line with default options for the TPPI protocol
func defaultLine() *Line {
	l := &Line{
		parts:     make([]string, 0, 1),
		joinRule:  JoinContents,
		splitRule: SplitContents,
		stuffingRules: map[string]Rules{
			"Stuffing": Stuff,
		},
		unStuffingRules: map[string]Rules{
			"UnStuffing": UnStuff,
		},
	}
	return l
}

// NewLine creates the new instance of the Line with InLiner interface
// signature and Line specific options
func NewLine(op ...LineOptions) InLiner {
	l := defaultLine()
	for _, o := range op {
		l = o(l)
	}
	return l
}
