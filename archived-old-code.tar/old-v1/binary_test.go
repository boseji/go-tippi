// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package tppi

import (
	"bytes"
	"reflect"
	"testing"
)

func TestToBinary(t *testing.T) {
	type args struct {
		arg          any
		littleEndian bool
	}
	tests := []struct {
		name    string
		args    args
		wantBuf *bytes.Buffer
		wantErr bool
	}{
		{
			name: "Normal conversion of a uint32 variable",
			args: args{
				arg:          uint32(0x3508),
				littleEndian: true,
			},
			wantBuf: bytes.NewBuffer([]byte{
				0x08, 0x35, 0x00, 0x00,
			}),
		},
		{
			name: "Normal conversion of a float64 variable",
			args: args{
				arg:          float64(10.34e15),
				littleEndian: true,
			},
			wantBuf: bytes.NewBuffer([]byte{
				0, 32, 125, 109, 22, 94, 66, 67,
			}),
		},
		{
			name: "Negative for string variable",
			args: args{
				arg:          "Testing String",
				littleEndian: true,
			},
			wantBuf: bytes.NewBuffer([]byte{}),
			wantErr: true,
		},
		{
			name: "Negative Struct variable with variable fields",
			args: args{
				arg: struct {
					i uint16
					v float32
					b uint8
					s string
				}{
					i: 0x3508,
					v: 12.5,
					b: 23,
					s: "Hari Aum",
				},
				littleEndian: true,
			},
			wantBuf: bytes.NewBuffer([]byte{}),
			wantErr: true,
		},
		{
			name: "Conversion of a Struct variable with Fixed length fields",
			args: args{
				arg: struct {
					i uint16
					v float32
					b uint8
				}{
					i: 0x3508,
					v: 12.5,
					b: 23,
				},
				littleEndian: true,
			},
			wantBuf: bytes.NewBuffer([]byte{8, 53, 0, 0, 72, 65, 23}),
		},
		{
			name: "Normal conversion of a uint32 variable in bigEndian",
			args: args{
				arg:          uint32(0x3508),
				littleEndian: false,
			},
			wantBuf: bytes.NewBuffer([]byte{
				0x00, 0x00, 0x35, 0x08,
			}),
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			buf := new(bytes.Buffer)
			err := ToBinary(tt.args.arg, tt.args.littleEndian,
				buf)
			if (err != nil) != tt.wantErr {
				t.Errorf("ToBinary() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(buf, tt.wantBuf) && !tt.wantErr {
				t.Errorf("ToBinary() = %v, want %v",
					buf.Bytes(), tt.wantBuf.Bytes())
			}
		})
	}
}

func TestFromBinary(t *testing.T) {
	t.Run("Normal conversion of a uint32 variable", func(t *testing.T) {
		var v, o uint32 = 0, 0x3508
		buf := bytes.NewBuffer([]byte{0x08, 0x35, 0x00, 0x00})
		err := FromBinary(&v, buf, true)
		if err != nil {
			t.Errorf("FromBinary() error = %v", err)
		}

		if v != o {
			t.Errorf("Expected %v got %v", o, v)
		}
	})
	t.Run("Normal conversion of a float64 variable", func(t *testing.T) {
		var v, o float64 = 0, float64(10.34e15)
		buf := bytes.NewBuffer([]byte{0, 32, 125, 109, 22, 94, 66, 67})
		err := FromBinary(&v, buf, true)
		if err != nil {
			t.Errorf("FromBinary() error = %v", err)
		}

		if v != o {
			t.Errorf("Expected %v got %v", o, v)
		}
	})
	t.Run("Negative conversion of a string variable", func(t *testing.T) {
		var v string = ""
		buf := bytes.NewBuffer([]byte{})
		err := FromBinary(v, buf, true)
		if err == nil {
			t.Errorf("FromBinary() No error")
		}
	})
	t.Run("BigEndian conversion of a uint32 variable", func(t *testing.T) {
		var v, o uint32 = 0, 0x3508
		buf := bytes.NewBuffer([]byte{0x00, 0x00, 0x35, 0x08})
		err := FromBinary(&v, buf, false)
		if err != nil {
			t.Errorf("FromBinary() error = %v", err)
		}

		if v != o {
			t.Errorf("Expected %v got %v", o, v)
		}
	})
}
