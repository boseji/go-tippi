// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package tppi

import (
	"fmt"
	"strings"
)

// Protocol describes the contents in the TPPI packet constrained by the
// Various input requirements.
type Protocol struct {
	StartStop   bool    // Needs the Start and Stop Symbols or Not
	Liner       InLiner // Tool to Inline Data for the TPPI Packet
	Data        []Spec  // Collection of Specs that form the data core
	Separator   string  // Used to Separate the lines
	StartMarker string  // Use to mark the Starting of the Protocol Packet
	EndMarker   string  // used to mark the Ending of the Protocol Packet
}

// ProtocolOptions is a Function type that specifies the functional parameters
// for various TPPI protocol needs.
type ProtocolOptions func(*Protocol) (*Protocol, error)

// Default options for the Protocol
func defaultOptions() *Protocol {
	p := &Protocol{
		StartStop:   true,
		Liner:       NewLine(),
		Data:        nil,
		Separator:   SEP_CONTENT,
		StartMarker: SYM_START,
		EndMarker:   SYM_END,
	}
	return p
}

// NewProtocol helps to create the TPPI Protocol structure
func NewProtocol(op ...ProtocolOptions) (p *Protocol, err error) {
	p = defaultOptions()
	for _, o := range op {
		var tp *Protocol
		tp, err = o(p)
		if err != nil {
			err = fmt.Errorf("failed to create protocol - \n%v", err)
			return
		}
		p = tp
	}
	return
}

// WithStartStop controls the StartStop feature requirement for TPPI protocol
func WithStartStop(need bool) ProtocolOptions {
	return func(p *Protocol) (*Protocol, error) {
		p.StartStop = need
		return p, nil
	}
}

// WithInLiner sets up the InLiner needed to assemble the Specs into the
// TPPI Protocol packet
func WithInLiner(l InLiner) ProtocolOptions {
	return func(p *Protocol) (*Protocol, error) {
		p.Liner = l
		return p, nil
	}
}

// WithSymbol allows to set custom symbols for the TPPI Protocol
func WithSymbols(sep, start, end string) ProtocolOptions {
	return func(p *Protocol) (*Protocol, error) {
		p.Separator = sep
		p.StartMarker = start
		p.EndMarker = end
		return p, nil
	}
}

// With option helps to add Spec to the TPPI Protocol
func With(sa ...Spec) ProtocolOptions {
	return func(p *Protocol) (*Protocol, error) {
		return p.Add(sa...), nil
	}
}

// Add helps to build the Spec collection for the TPPI Protocol
func (p *Protocol) Add(sa ...Spec) *Protocol {
	bx := make([]Spec, 0, len(p.Data)+len(sa))
	bx = append(bx, p.Data...)
	bx = append(bx, sa...)
	p.Data = bx
	return p
}

// Build creates the TPPI Packet
func (p *Protocol) Build() (s string, err error) {
	// Perform Checks
	if len(p.Data) == 0 {
		err = fmt.Errorf("failed to build packet as no data available")
		return
	}
	if p.Liner == nil {
		err = fmt.Errorf("failed to build packet as no inliner specified")
		return
	}
	// Build the collection
	sa := make([]string, 0, len(p.Data)*2)
	for _, d := range p.Data {
		var sv []string
		var sig, value string
		// Add Signature
		sig, err = RunLiner(p.Liner, d.Sig()...)
		if err != nil {
			err = fmt.Errorf("failed to add signature due to error - %v", err)
			return
		}
		// Get the Value
		sv, err = d.Get()
		if err != nil {
			err = fmt.Errorf("failed to get value for spec due to error - %v",
				err)
			return
		}
		// Add Value
		value, err = RunLiner(p.Liner, sv...)
		if err != nil {
			err = fmt.Errorf("failed to add value due to error - %v", err)
			return
		}
		sa = append(sa, sig, value)
	}

	// Prepare the String
	s = strings.Join(sa, p.Separator)
	// Check if we need Start and End
	if p.StartStop {
		s = p.StartMarker + s + p.EndMarker
	}
	return
}
