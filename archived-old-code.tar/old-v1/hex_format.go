// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package tppi

import (
	"bytes"
	"encoding/hex"
	"fmt"
)

const (
	hexFormatMark = "H"
)

// HexFormat is the Hex Format Encoding and Decoding Handlers
type HexFormat struct {
	LittleEndian bool
}

// HexFormatOptions helps to setup the HexFormat Formatter
type HexFormatOptions func(*HexFormat) *HexFormat

// Mark implements the Formatter interface for the HexFormat
func (h HexFormat) Mark() string {
	return hexFormatMark
}

// Encode implements the Formatter interface for HexFormat
func (h HexFormat) Encode(arg any) (s string, err error) {
	buf := new(bytes.Buffer)
	switch v := arg.(type) {
	case []byte:
		buf.Write(v)
	case string:
		buf.WriteString(v)
	default:
		err = ToBinary(arg, h.LittleEndian, buf)
		if err != nil {
			err = fmt.Errorf("failed to hex encode: %v", err)
			return
		}
	}
	// Perform Hex encoding
	s = hex.EncodeToString(buf.Bytes())
	return
}

// Decode implements the Formatter interface for HexFormat
func (h HexFormat) Decode(arg any, s string) (val any, err error) {
	bs, err := hex.DecodeString(s)
	if err != nil {
		err = fmt.Errorf("failed to hex decode string: %v", err)
		return
	}
	switch v := arg.(type) {
	case string:
		val = string(bs)
		return
	case []byte:
		val = bs
		return
	default:
		buf := bytes.NewBuffer(bs)
		err = FromBinary(arg, buf, h.LittleEndian)
		_ = v
	}

	if err != nil {
		err = fmt.Errorf("failed to hex decode and convert to data type: %v",
			err)
		return
	}
	val = arg
	return
}

// WithHexFormatInBigEndian helps to setup BigEndian system
func WithHexFormatInBigEndian() HexFormatOptions {
	return func(hf *HexFormat) *HexFormat {
		hf.LittleEndian = false
		return hf
	}
}

// defaultHexFormat is the default options for the HexFormat
func defaultHexFormat() *HexFormat {
	return &HexFormat{LittleEndian: true}
}

// NewHexFormat creates a new HexFormat encoder/decoder for data
func NewHexFormat(op ...HexFormatOptions) Formatter {
	hf := defaultHexFormat()
	for _, o := range op {
		hf = o(hf)
	}
	return hf
}
