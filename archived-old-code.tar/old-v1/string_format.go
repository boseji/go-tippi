// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package tppi

import "fmt"

const (
	stringFormatMark = "S"
)

// StringFormat represents the data in their printable form
type StringFormat struct {
	Format string
}

// StringFormatOptions provides a way to configure the String formatter
type StringFormatOptions func(*StringFormat) *StringFormat

// Mark implements the Formatter interface for the StringFormat
func (sf StringFormat) Mark() string {
	return stringFormatMark
}

// Encode implements the Formatter interface for StringFormat
func (sf StringFormat) Encode(arg any) (s string, err error) {
	return fmt.Sprintf(sf.Format, arg), nil
}

// Decode implements the Formatter interface for StringFormat
func (sf StringFormat) Decode(arg any, s string) (val any, err error) {
	_, err = fmt.Sscanf(s, sf.Format, arg)
	val = arg
	return
}

// WithStringFormat allows to set custom String format for encoding and decoding
func WithStringFormat(s string) StringFormatOptions {
	return func(sf *StringFormat) *StringFormat {
		sf.Format = s
		return sf
	}
}

// defaultStringFormat setup the default String Format options
func defaultStringFormat() *StringFormat {
	return &StringFormat{
		Format: "%v",
	}
}

// NewStringFormat defines the String formatter
func NewStringFormat(op ...StringFormatOptions) Formatter {
	sf := defaultStringFormat()
	for _, o := range op {
		sf = o(sf)
	}
	return sf
}
