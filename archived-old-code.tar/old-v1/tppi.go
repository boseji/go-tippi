// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

// Tilde Pipe simPle Interface

package tppi

import "fmt"

// InLiner is a type that helps to prepare data as per the TPPI protocol needs
type InLiner interface {
	// Add collection of strings to a line
	Add(...string) error
	// Gets the Contents from the InLiner
	Contents() []string
	// Get the output with proper formatting for the line
	Processed() (string, error)
	// Restore contents from a processes line as input
	Decode(string) error
	// Clear the contents of the InLiner
	Clear()
}

// Formatter is the Encoding format for the TPPI
type Formatter interface {
	// Provides a unique signature that indicates which formatter to use
	Mark() string
	// Provides a way to translate any datatype into the specified format
	Encode(any) (string, error)
	// Provides a way to translate the string back to specified datatype
	Decode(any, string) (any, error)
}

// Spec provides a way to specify the data representation form for
// TPPI protocol. This encloses an unique signature, formatter and
// the value of the given data.
type Spec interface {
	// A unique signature of the data representation
	Sig() []string
	// Set a Encoding format for the Data present in the spec
	Format(Formatter) error
	// Provides a Value Representation of the data to be processed
	Get() ([]string, error)
	// Helps to recover the data embedded, the first parameter being
	// the Signature and the second being the value.
	Restore([]string, []string) error
}

// RunLiner helps to automate the Steps involved in creation of the single
// InLine from the collection on inputs.
func RunLiner(l InLiner, sa ...string) (s string, err error) {
	// Clear the Liner
	l.Clear()
	// Add array
	err = l.Add(sa...)
	if err != nil {
		err = fmt.Errorf("failed to add strings to the inliner - %v", err)
		return
	}
	// Get String
	s, err = l.Processed()
	if err != nil {
		err = fmt.Errorf("failed to process the strings from inliner - %v", err)
		return
	}
	return
}
