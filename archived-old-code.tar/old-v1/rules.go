// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package tppi

import "fmt"

// Rules are specific operations followed for representation of a Line in
// the TPPI Protocol
type Rules func(string) (string, error)

// CollectionRule applies on a collection of Strings to prepare a specific
// Representation
type CollectionRule func(...string) (string, error)

// Splitting Rule breaks the input into a Collection of strings from
// and input containing a specific format
type SplittingRule func(string) ([]string, error)

// RunRules helps to run a collection of rules on a collection of input
// strings.
func RunRules(ra map[string]Rules, sa ...string) (sv []string, err error) {
	if len(sa) == 0 {
		err = fmt.Errorf("no inputs supplied to run rules")
		return
	}
	if len(ra) == 0 {
		err = fmt.Errorf("no rules specified to run")
		return
	}

	// Build
	sv = make([]string, 0, len(sa))
	for _, si := range sa {
		for name, r := range ra {
			var tmp string
			tmp, err = r(si)
			if err != nil {
				err = fmt.Errorf("error running %q rule - %v", name, err)
				return
			}
			si = tmp
		}
		sv = append(sv, si)
	}
	return
}
