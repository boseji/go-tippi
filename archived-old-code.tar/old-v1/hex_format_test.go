// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package tppi

import (
	"reflect"
	"testing"
)

func TestHexFormat_Encode(t *testing.T) {
	tests := []struct {
		name         string
		LittleEndian bool
		arg          any
		wantS        string
		wantErr      bool
	}{
		{
			name:         "Positive []byte slice",
			LittleEndian: true,
			arg: []byte{
				0x35, 0x08,
			},
			wantS: "3508",
		},
		{
			name:         "Positive string",
			LittleEndian: true,
			arg:          "Hare Krishna",
			wantS:        "48617265204b726973686e61",
		},
		{
			name:         "Positive uint32",
			LittleEndian: true,
			arg:          uint32(0x3508),
			wantS:        "08350000",
		},
		{
			name:         "Positive uint32 bigEndian",
			LittleEndian: false,
			arg:          uint32(0x3508),
			wantS:        "00003508",
		},
		{
			name:         "Positive float64",
			LittleEndian: true,
			arg:          float64(10.34e15),
			wantS:        "00207d6d165e4243",
		},
		{
			name:         "Positive float64 bigEndian",
			LittleEndian: false,
			arg:          float64(10.34e15),
			wantS:        "43425e166d7d2000",
		},
		{
			name:         "Positive bool",
			LittleEndian: true,
			arg:          false,
			wantS:        "00",
		},
		{
			name:         "Positive bool bigEndian",
			LittleEndian: false,
			arg:          true,
			wantS:        "01",
		},
		{
			name:         "Negative []string",
			LittleEndian: true,
			arg:          []string{"A", "B"},
			wantS:        "01",
			wantErr:      true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			h := HexFormat{
				LittleEndian: tt.LittleEndian,
			}
			gotS, err := h.Encode(tt.arg)
			if (err != nil) != tt.wantErr {
				t.Errorf("HexFormat.encode() error = %v, wantErr %v",
					err, tt.wantErr)
				return
			}
			if gotS != tt.wantS && !tt.wantErr {
				t.Errorf("HexFormat.encode() = %v, want %v", gotS, tt.wantS)
			}
		})
	}
}

func TestHexFormat_Decode(t *testing.T) {
	type args struct {
		arg any
		s   string
	}
	tests := []struct {
		name         string
		LittleEndian bool
		args         args
		wantVal      any
		wantErr      bool
	}{
		{
			name:         "Positive []byte slice",
			LittleEndian: true,
			args: args{
				arg: make([]byte, 1),
				s:   "3508",
			},
			wantVal: []byte{0x35, 0x08},
		},
		{
			name:         "Positive string",
			LittleEndian: true,
			args: args{
				arg: "",
				s:   "48617265204b726973686e61",
			},
			wantVal: "Hare Krishna",
		},
		{
			name:         "Positive uint32",
			LittleEndian: true,
			args: args{
				arg: new(uint32),
				s:   "08350000",
			},
			wantVal: func() *uint32 {
				var v uint32 = 0x3508
				return &v
			}(),
		},
		{
			name:         "Positive uint32 bigEndian",
			LittleEndian: false,
			args: args{
				arg: new(uint32),
				s:   "00003508",
			},
			wantVal: func() *uint32 {
				var v uint32 = 0x3508
				return &v
			}(),
		},
		{
			name:         "Positive float64",
			LittleEndian: true,
			args: args{
				arg: new(float64),
				s:   "00207d6d165e4243",
			},
			wantVal: func() *float64 {
				var v float64 = 10.34e15
				return &v
			}(),
		},
		{
			name:         "Positive float64 bigEndian",
			LittleEndian: false,
			args: args{
				arg: new(float64),
				s:   "43425e166d7d2000",
			},
			wantVal: func() *float64 {
				var v float64 = 10.34e15
				return &v
			}(),
		},
		{
			name:         "Positive bool",
			LittleEndian: true,
			args: args{
				arg: new(bool),
				s:   "00",
			},
			wantVal: func() *bool {
				var v bool = false
				return &v
			}(),
		},
		{
			name:         "Positive bool bigEndian",
			LittleEndian: false,
			args: args{
				arg: new(bool),
				s:   "01",
			},
			wantVal: func() *bool {
				var v bool = true
				return &v
			}(),
		},
		{
			name:         "Negative []string",
			LittleEndian: true,
			args: args{
				arg: []string{"A", "B"},
				s:   "AB",
			},
			wantVal: nil,
			wantErr: true,
		},
		{
			name:         "Negative uint32 with wrong data",
			LittleEndian: true,
			args: args{
				arg: new(uint32),
				s:   "AB-+02",
			},
			wantVal: nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			h := HexFormat{
				LittleEndian: tt.LittleEndian,
			}
			gotVal, err := h.Decode(tt.args.arg, tt.args.s)
			if (err != nil) != tt.wantErr {
				t.Errorf("HexFormat.decode() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotVal, tt.wantVal) {
				t.Errorf("HexFormat.decode() = %v, want %v", gotVal, tt.wantVal)
			}
		})
	}
}

func TestHexFormat_others(t *testing.T) {
	t.Run("mark and new test", func(t *testing.T) {
		h := NewHexFormat()
		if hf, ok := h.(HexFormat); ok && hf.LittleEndian != true {
			t.Errorf("Failed to setup the HexFormat")
		}
		if h.Mark() != hexFormatMark {
			t.Errorf("Failed to get correct mark for HexFormat")
		}
		h1 := NewHexFormat(WithHexFormatInBigEndian())
		if hf, ok := h1.(HexFormat); ok && hf.LittleEndian != false {
			t.Errorf("Failed to setup the HexFormat in BigEndian")
		}
	})
}
