// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package values

import "testing"

// Enclosed types

type encBool bool
type encInt int
type encInt8 int8
type encInt16 int16
type encInt32 int32
type encInt64 int64
type encUint uint
type encUint8 uint8
type encUint16 uint16
type encUint32 uint32
type encUint64 uint64
type encFloat32 float32
type encFloat64 float64

func TestDescribe(t *testing.T) {
	type args struct {
		u any
	}
	tests := []struct {
		name   string
		args   args
		wantBt BaseType
		wantCt ComposedType
	}{
		{
			name: "negative unknown interface type",
			args: args{
				u: any(nil),
			},
			wantBt: BaseInvalid,
			wantCt: ComposedBlankType,
		},
		{
			name: "bool type normal",
			args: args{
				u: true,
			},
			wantBt: BaseBool,
			wantCt: ComposedBlankType,
		},
		{
			name: "bool type pointer",
			args: args{
				u: new(bool),
			},
			wantBt: BaseBool,
			wantCt: ComposedBlankType,
		},
		{
			name: "negative bool type pointer nil",
			args: args{
				u: func() *bool {
					var v *bool
					return v
				}(),
			},
			wantBt: BaseInvalid,
			wantCt: ComposedBlankType,
		},
		{
			name: "bool type enclosed",
			args: args{
				u: encBool(true),
			},
			wantBt: BaseBool,
			wantCt: ComposedOverlay,
		},
		{
			name: "bool type enclosed pointer",
			args: args{
				u: new(encBool),
			},
			wantBt: BaseBool,
			wantCt: ComposedOverlay,
		},
		{
			name: "negative bool type enclosed pointer nil",
			args: args{
				u: func() *encBool {
					var v *encBool
					return v
				}(),
			},
			wantBt: BaseInvalid,
			wantCt: ComposedBlankType,
		},
		{
			name: "bool type slice",
			args: args{
				u: make([]bool, 1),
			},
			wantBt: BaseBool,
			wantCt: ComposedArray,
		},
		{
			name: "negative bool type pointer in slice",
			args: args{
				u: make([]*bool, 0),
			},
			wantBt: BaseInvalid,
			wantCt: ComposedBlankType,
		},
		{
			name: "bool enclosed type slice",
			args: args{
				u: make([]encBool, 1),
			},
			wantBt: BaseBool,
			wantCt: ComposedArray + ComposedOverlay,
		},
		{
			name: "negative bool enclosed pointer type slice",
			args: args{
				u: make([]*encBool, 0),
			},
			wantBt: BaseInvalid,
			wantCt: ComposedBlankType,
		},
		{
			name: "bool type Array",
			args: args{
				u: [1]bool{true},
			},
			wantBt: BaseBool,
			wantCt: ComposedArray,
		},
		{
			name: "negative bool pointer type Array",
			args: args{
				u: [1]*bool{new(bool)},
			},
			wantBt: BaseInvalid,
			wantCt: ComposedBlankType,
		},
		{
			name: "bool enclosed type Array",
			args: args{
				u: [1]encBool{true},
			},
			wantBt: BaseBool,
			wantCt: ComposedArray + ComposedOverlay,
		},
		{
			name: "negative bool enclosed pointer type Array",
			args: args{
				u: [1]*encBool{new(encBool)},
			},
			wantBt: BaseInvalid,
			wantCt: ComposedBlankType,
		},
		{
			name: "int type",
			args: args{
				u: int(-3),
			},
			wantBt: BaseInt64,
			wantCt: ComposedBlankType,
		},
		{
			name: "int type pointer",
			args: args{
				u: new(int),
			},
			wantBt: BaseInt64,
			wantCt: ComposedBlankType,
		},
		{
			name: "enclosed int type",
			args: args{
				u: encInt(-3),
			},
			wantBt: BaseInt64,
			wantCt: ComposedOverlay,
		},
		{
			name: "int8 type",
			args: args{
				u: int8(-3),
			},
			wantBt: BaseInt8,
			wantCt: ComposedBlankType,
		},
		{
			name: "enclosed int8 type",
			args: args{
				u: encInt8(-3),
			},
			wantBt: BaseInt8,
			wantCt: ComposedOverlay,
		},
		{
			name: "int16 type",
			args: args{
				u: int16(-3),
			},
			wantBt: BaseInt16,
			wantCt: ComposedBlankType,
		},
		{
			name: "enclosed int16 type",
			args: args{
				u: encInt16(-3),
			},
			wantBt: BaseInt16,
			wantCt: ComposedOverlay,
		},
		{
			name: "int32 type",
			args: args{
				u: int32(-3),
			},
			wantBt: BaseInt32,
			wantCt: ComposedBlankType,
		},
		{
			name: "enclosed int32 type",
			args: args{
				u: encInt32(-3),
			},
			wantBt: BaseInt32,
			wantCt: ComposedOverlay,
		},
		{
			name: "int64 type",
			args: args{
				u: int64(-3),
			},
			wantBt: BaseInt64,
			wantCt: ComposedBlankType,
		},
		{
			name: "enclosed int64 type",
			args: args{
				u: encInt64(-3),
			},
			wantBt: BaseInt64,
			wantCt: ComposedOverlay,
		},
		{
			name: "uint type",
			args: args{
				u: uint(3),
			},
			wantBt: BaseUint64,
			wantCt: ComposedBlankType,
		},
		{
			name: "enclosed uint type",
			args: args{
				u: encUint(3),
			},
			wantBt: BaseUint64,
			wantCt: ComposedOverlay,
		},
		{
			name: "uint8 type",
			args: args{
				u: uint8(3),
			},
			wantBt: BaseUint8,
			wantCt: ComposedBlankType,
		},
		{
			name: "enclosed uint8 type",
			args: args{
				u: encUint8(3),
			},
			wantBt: BaseUint8,
			wantCt: ComposedOverlay,
		},
		{
			name: "uint16 type",
			args: args{
				u: uint16(3),
			},
			wantBt: BaseUint16,
			wantCt: ComposedBlankType,
		},
		{
			name: "enclosed uint16 type",
			args: args{
				u: encUint16(3),
			},
			wantBt: BaseUint16,
			wantCt: ComposedOverlay,
		},
		{
			name: "uint32 type",
			args: args{
				u: uint32(3),
			},
			wantBt: BaseUint32,
			wantCt: ComposedBlankType,
		},
		{
			name: "enclosed uint32 type",
			args: args{
				u: encUint32(3),
			},
			wantBt: BaseUint32,
			wantCt: ComposedOverlay,
		},
		{
			name: "uint64 type",
			args: args{
				u: uint64(3),
			},
			wantBt: BaseUint64,
			wantCt: ComposedBlankType,
		},
		{
			name: "enclosed uint64 type",
			args: args{
				u: encUint64(3),
			},
			wantBt: BaseUint64,
			wantCt: ComposedOverlay,
		},
		{
			name: "Float32 type",
			args: args{
				u: float32(-3.2e5),
			},
			wantBt: BaseFloat32,
			wantCt: ComposedBlankType,
		},
		{
			name: "enclosed Float32 type",
			args: args{
				u: encFloat32(-3.2e5),
			},
			wantBt: BaseFloat32,
			wantCt: ComposedOverlay,
		},
		{
			name: "Float64 type",
			args: args{
				u: float64(-3.2e5),
			},
			wantBt: BaseFloat64,
			wantCt: ComposedBlankType,
		},
		{
			name: "enclosed Float64 type",
			args: args{
				u: encFloat64(-3.2e5),
			},
			wantBt: BaseFloat64,
			wantCt: ComposedOverlay,
		},
		{
			name: "Negative map type",
			args: args{
				u: map[string]string{},
			},
			wantBt: BaseInvalid,
			wantCt: ComposedBlankType,
		},
		{
			name: "Negative struct type",
			args: args{
				u: struct{ n int }{},
			},
			wantBt: BaseInvalid,
			wantCt: ComposedBlankType,
		},
		{
			name: "Negative Array pointer type",
			args: args{
				u: [2]*bool{new(bool), new(bool)},
			},
			wantBt: BaseInvalid,
			wantCt: ComposedBlankType,
		},
		{
			name: "Negative Slice pointer type",
			args: args{
				u: []*bool{new(bool), new(bool)},
			},
			wantBt: BaseInvalid,
			wantCt: ComposedBlankType,
		},
		{
			name: "Pointer to Array [2]bool type",
			args: args{
				u: func() *[2]bool {
					v := [2]bool{true, false}
					return &v
				}(),
			},
			wantBt: BaseBool,
			wantCt: ComposedArray,
		},
		{
			name: "Pointer to []bool Slice type",
			args: args{
				u: func() *[]bool {
					v := []bool{true, false}
					return &v
				}(),
			},
			wantBt: BaseBool,
			wantCt: ComposedArray,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotBt, gotCt := Describe(tt.args.u)
			if gotBt != tt.wantBt {
				t.Errorf("Describe() gotBt = %v, want %v", gotBt, tt.wantBt)
			}
			if gotCt != tt.wantCt {
				t.Errorf("Describe() gotCt = %v, want %v", gotCt, tt.wantCt)
			}
		})
	}
}
