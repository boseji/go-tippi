// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package values

import (
	"reflect"
)

// Basic Type
type BaseType uint8

const (
	BaseInvalid BaseType = iota
	BaseBool
	BaseInt8
	BaseInt16
	BaseInt32
	BaseInt64
	BaseUint8
	BaseUint16
	BaseUint32
	BaseUint64
	BaseFloat32
	BaseFloat64
	// They do not need a Size parameter
	BaseString
	// Special type that caters to Maps, Tuples, Structures and any collections
	BaseComposed
	MaxBaseType
	MaskBaseType BaseType = 0x0F
)

// ComposedType specifies the specialty over the BaseType
type ComposedType uint8

const (
	ComposedBlankType ComposedType = iota << 4
	// ComposedArray includes both Slice and fixed ComposedArray
	// They also include a size parameter usually added to the definition.
	ComposedArray ComposedType = iota << 4
	// ComposedOverlay is an enclosed type with Values composed of other Basic types
	ComposedOverlay ComposedType = iota << 5
	// ComposedCollection is Map or Tuple like a Key-Value pair with
	// individual types specified for both the Key and value elements.
	// Structs are a type of Map with their fields as Key.
	ComposedCollection ComposedType = iota << 6
)

// describeValue helps to describe the type of the basic values
func describeValue(kind reflect.Kind, tName string, pct ComposedType) (
	bt BaseType, ct ComposedType,
) {
	ct = pct
	// Type Switch
	switch kind {
	case reflect.Bool:
		if reflect.Bool.String() != tName {
			ct += ComposedOverlay
		}
		bt = BaseBool
	case reflect.Int:
		if reflect.Int.String() != tName {
			ct += ComposedOverlay
		}
		bt = BaseInt64
	case reflect.Int8:
		if reflect.Int8.String() != tName {
			ct += ComposedOverlay
		}
		bt = BaseInt8
	case reflect.Int16:
		if reflect.Int16.String() != tName {
			ct += ComposedOverlay
		}
		bt = BaseInt16
	case reflect.Int32:
		if reflect.Int32.String() != tName {
			ct += ComposedOverlay
		}
		bt = BaseInt32
	case reflect.Int64:
		if reflect.Int64.String() != tName {
			ct += ComposedOverlay
		}
		bt = BaseInt64
	case reflect.Uint:
		if reflect.Uint.String() != tName {
			ct += ComposedOverlay
		}
		bt = BaseUint64
	case reflect.Uint8:
		if reflect.Uint8.String() != tName {
			ct += ComposedOverlay
		}
		bt = BaseUint8
	case reflect.Uint16:
		if reflect.Uint16.String() != tName {
			ct += ComposedOverlay
		}
		bt = BaseUint16
	case reflect.Uint32:
		if reflect.Uint32.String() != tName {
			ct += ComposedOverlay
		}
		bt = BaseUint32
	case reflect.Uint64:
		if reflect.Uint64.String() != tName {
			ct += ComposedOverlay
		}
		bt = BaseUint64
	case reflect.Float32:
		if reflect.Float32.String() != tName {
			ct += ComposedOverlay
		}
		bt = BaseFloat32
	case reflect.Float64:
		if reflect.Float64.String() != tName {
			ct += ComposedOverlay
		}
		bt = BaseFloat64
	default:
		return
	}
	return
}

// describeSlice helps to describe the type for Slices and Arrays
func describeSlice(val reflect.Value, pct ComposedType) (
	bt BaseType, ct ComposedType,
) {
	eVal := val.Type().Elem()
	eKind := eVal.Kind()

	// Difficult to process types
	if eKind == reflect.Chan || eKind == reflect.Func ||
		eKind == reflect.Interface || eKind == reflect.Invalid ||
		eKind == reflect.Uintptr || eKind == reflect.UnsafePointer ||
		eKind == reflect.Complex64 || eKind == reflect.Complex128 ||
		eKind == reflect.Array || eKind == reflect.Map ||
		eKind == reflect.Slice || eKind == reflect.Struct ||
		eKind == reflect.Pointer {
		return
	}

	eName := val.Type().Elem().Name()

	return describeValue(eKind, eName, ComposedArray+pct)
}

// Describe provides a way to identify the BaseType and ComposedType for any
// Data supplied.
func Describe(u any) (bt BaseType, ct ComposedType) {
	val := reflect.ValueOf(u)
	kind := val.Kind()

	// Can't process any nil values
	if kind == reflect.Pointer && val.IsNil() {
		return
	}
	// Filter out the Pointer type
	if kind == reflect.Pointer {
		kind = val.Elem().Kind()
		val = val.Elem()
	}
	// Difficult to process types
	if kind == reflect.Chan || kind == reflect.Func ||
		kind == reflect.Interface || kind == reflect.Invalid ||
		kind == reflect.Uintptr || kind == reflect.UnsafePointer ||
		kind == reflect.Complex64 || kind == reflect.Complex128 {
		return
	}
	// Type Switch
	switch kind {
	case reflect.Array:
		return describeSlice(val, ComposedBlankType)
	case reflect.Map:
		// bt = Composed
		// ct = ComposedCollection
		return
	case reflect.Slice:
		return describeSlice(val, ComposedBlankType)
	case reflect.Struct:
		// bt = Composed
		// ct = ComposedCollection
		return
	default:
		tName := val.Type().Name()
		return describeValue(kind, tName, ComposedBlankType)
	}
}
