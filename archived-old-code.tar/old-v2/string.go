// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package tppi

import (
	"bytes"
	"fmt"

	"guthub.com/boseji/go-tppi/values"
)

func ToString(arg any, format string, buf *bytes.Buffer) (err error) {
	bt, _ := values.Describe(arg)
	if bt == values.BaseInvalid {
		err = fmt.Errorf("unsupported type for string conversion")
		return
	}
	// Prepare the String
	s := fmt.Sprintf(format, arg)
	n, err := buf.WriteString(s)
	if err != nil {
		err = fmt.Errorf("failed to convert to string due to - %v", err)
		return
	}
	if n != len(s) {
		err = fmt.Errorf("insufficient data written for string conversion")
	}
	return
}

func FromString(arg any, buf *bytes.Buffer, format string) (err error) {
	bt, _ := values.Describe(arg)
	if bt == values.BaseInvalid {
		err = fmt.Errorf("unsupported type for string recovery")
		return
	}
	n, err := fmt.Fscanf(buf, format, arg)
	if err != nil {
		err = fmt.Errorf("failed to recover string from buffer as - %v", err)
		return
	}
	if n != 1 {
		err = fmt.Errorf("could not recover the string properly")
	}
	return
}
