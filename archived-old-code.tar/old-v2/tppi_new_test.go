// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

// Tilde Pipe simPle Interface

package tppi

import (
	"encoding/binary"
	"fmt"
	"reflect"
	"testing"
)

func codeUint(u any) (s string, err error) {
	// Get Value Handle
	val := reflect.ValueOf(u)
	// Get the Kind
	k := val.Kind()
	// Used to Pull Values from
	v := val
	if k == reflect.Pointer {
		k = val.Elem().Kind()
		v = val.Elem()
	}
	switch k {
	case reflect.Bool:
		fmt.Println(v.Type().String(), val.Kind(), v.Bool())
	case reflect.Slice:
		fmt.Println(v.Cap(), v.Len(), v.Type().Elem().Kind())
	case reflect.Int:
		fmt.Println(binary.Size(val.Int()), val.Int())
	case reflect.Uint32:
		fmt.Println(binary.Size(val.Uint()), val.Uint())
	default:
		err = fmt.Errorf("wrong type: %s", k.String())
		return
	}
	return
}
func Test_ReflectBasic(t *testing.T) {
	type possible bool
	v := true
	xs := []byte{1, 2, 3}
	st := struct {
		Name string
		Id   uint16
	}{
		Name: "Mohan",
		Id:   33,
	}
	pv := possible(true)
	fmt.Println("Bool", v)
	fmt.Println("Byte Slice", xs)
	fmt.Printf("Struct %#v\n", st)
	fmt.Print("Bool Value = ")
	fmt.Println(codeUint(v))
	fmt.Print("Bool Pointer = ")
	fmt.Println(codeUint(&v))
	fmt.Print("ByteSlice = ")
	fmt.Println(codeUint(xs))
	fmt.Print("ByteSlice Pointer = ")
	fmt.Println(codeUint(&xs))
	fmt.Print("Struct = ")
	fmt.Println(codeUint(st))
	fmt.Print("Struct Pointer = ")
	fmt.Println(codeUint(&st))
	fmt.Print("Special Value enclosed Boolean = ")
	fmt.Println(codeUint(pv))
	fmt.Print("Special Pointer enclosed Boolean = ")
	fmt.Println(codeUint(&pv))
	fmt.Print("Blank Byte Slice = ")
	fmt.Println(codeUint(make([]byte, 0)))
	fmt.Print("int = ")
	fmt.Println(codeUint(int(5)))
	fmt.Print("uint32 = ")
	fmt.Println(codeUint(uint32(5)))
}
