// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package tppi

import (
	"reflect"
	"testing"
)

func TestIsStuffed(t *testing.T) {
	tests := []struct {
		name string
		args string
		want bool
	}{
		{
			name: "un-stuffed",
			args: "||Hare Krishna ~",
			want: true,
		},
		{
			name: "stuffed",
			args: "\\x7CHare Krishna \\x2D",
			want: false,
		},
		{
			name: "NoStuff Needed",
			args: "Hare Krishna",
			want: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := NeedsStuff(tt.args); got != tt.want {
				t.Errorf("IsStuffed() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestStuff(t *testing.T) {
	type args struct {
		s string
	}
	tests := []struct {
		name    string
		args    args
		wantSv  string
		wantErr bool
	}{
		{
			name: "Negative Empty string",
			args: args{
				"",
			},
			wantErr: true,
		},
		{
			name: "Positive with one Pipe",
			args: args{
				"Hare |Krishna",
			},
			wantSv: "Hare \\x7CKrishna",
		},
		{
			name: "Positive with double Pipe combo",
			args: args{
				"Hare ||Krishna|",
			},
			wantSv: "Hare \\x7C\\x7CKrishna\\x7C",
		},
		{
			name: "Positive with one Pipe + tilde combo",
			args: args{
				"~Hare |Kri~~shna",
			},
			wantSv: "\\x2DHare \\x7CKri\\x2D\\x2Dshna",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotSv, err := Stuff(tt.args.s)
			if (err != nil) != tt.wantErr {
				t.Errorf("Stuff() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if gotSv != tt.wantSv {
				t.Errorf("Stuff() = %v, want %v", gotSv, tt.wantSv)
			}
		})
	}
}

func TestUnStuff(t *testing.T) {
	type args struct {
		s string
	}
	tests := []struct {
		name    string
		args    args
		wantSv  string
		wantErr bool
	}{
		{
			name: "Negative Empty string",
			args: args{
				"",
			},
			wantErr: true,
		},
		{
			name: "Positive with one Pipe",
			args: args{
				"Hare \\x7CKrishna",
			},
			wantSv: "Hare |Krishna",
		},
		{
			name: "Positive with double Pipe combo",
			args: args{
				"Hare \\x7C\\x7CKrishna\\x7C",
			},
			wantSv: "Hare ||Krishna|",
		},
		{
			name: "Positive with one Pipe + tilde combo",
			args: args{
				"\\x2DHare \\x7CKri\\x2D\\x2Dshna",
			},
			wantSv: "~Hare |Kri~~shna",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotSv, err := UnStuff(tt.args.s)
			if (err != nil) != tt.wantErr {
				t.Errorf("UnStuff() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if gotSv != tt.wantSv {
				t.Errorf("UnStuff() = %v, want %v", gotSv, tt.wantSv)
			}
		})
	}
}

func TestJoinLines(t *testing.T) {
	type args struct {
		sa []string
	}
	tests := []struct {
		name    string
		args    args
		wantS   string
		wantErr bool
	}{
		{
			name: "Negative blank input",
			args: args{
				sa: nil,
			},
			wantErr: true,
		},
		{
			name: "Positive Single string",
			args: args{
				sa: []string{
					"Hare Krishna",
				},
			},
			wantS: "Hare Krishna",
		},
		{
			name: "Positive Multiple string",
			args: args{
				sa: []string{
					"Hare Krishna",
					"Hare Krishna",
				},
			},
			wantS: "Hare Krishna|Hare Krishna",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotS, err := JoinLines(tt.args.sa...)
			if (err != nil) != tt.wantErr {
				t.Errorf("JoinLines() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if gotS != tt.wantS {
				t.Errorf("JoinLines() = %v, want %v", gotS, tt.wantS)
			}
		})
	}
}

func TestJoinContents(t *testing.T) {
	type args struct {
		sa []string
	}
	tests := []struct {
		name    string
		args    args
		wantS   string
		wantErr bool
	}{
		{
			name: "Negative blank input",
			args: args{
				sa: nil,
			},
			wantErr: true,
		},
		{
			name: "Positive Single string",
			args: args{
				sa: []string{
					"Hare Krishna",
				},
			},
			wantS: "Hare Krishna",
		},
		{
			name: "Positive Multiple string",
			args: args{
				sa: []string{
					"Hare Krishna",
					"Hare Krishna",
				},
			},
			wantS: "Hare Krishna~Hare Krishna",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotS, err := JoinContents(tt.args.sa...)
			if (err != nil) != tt.wantErr {
				t.Errorf("JoinContents() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if gotS != tt.wantS {
				t.Errorf("JoinContents() = %v, want %v", gotS, tt.wantS)
			}
		})
	}
}

func TestSplitLines(t *testing.T) {
	type args struct {
		s string
	}
	tests := []struct {
		name    string
		args    args
		wantSa  []string
		wantErr bool
	}{
		{
			name: "Negative Empty string",
			args: args{
				s: "",
			},
			wantSa:  nil,
			wantErr: true,
		},
		{
			name: "Positive Single string",
			args: args{
				s: "Hare Krishna",
			},
			wantSa: []string{"Hare Krishna"},
		},
		{
			name: "Positive Multiple string",
			args: args{
				s: "Hare Krishna|Hare Ram|Hare Hare",
			},
			wantSa: []string{
				"Hare Krishna",
				"Hare Ram",
				"Hare Hare",
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotSa, err := SplitLines(tt.args.s)
			if (err != nil) != tt.wantErr {
				t.Errorf("SplitLines() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotSa, tt.wantSa) {
				t.Errorf("SplitLines() = %v, want %v", gotSa, tt.wantSa)
			}
		})
	}
}

func TestSplitContents(t *testing.T) {
	type args struct {
		s string
	}
	tests := []struct {
		name    string
		args    args
		wantSa  []string
		wantErr bool
	}{
		{
			name: "Negative Empty string",
			args: args{
				s: "",
			},
			wantSa:  nil,
			wantErr: true,
		},
		{
			name: "Positive Single string",
			args: args{
				s: "Hare Krishna",
			},
			wantSa: []string{"Hare Krishna"},
		},
		{
			name: "Positive Multiple string",
			args: args{
				s: "Hare Krishna~Hare Ram~Hare Hare",
			},
			wantSa: []string{
				"Hare Krishna",
				"Hare Ram",
				"Hare Hare",
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotSa, err := SplitContents(tt.args.s)
			if (err != nil) != tt.wantErr {
				t.Errorf("SplitContents() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotSa, tt.wantSa) {
				t.Errorf("SplitContents() = %v, want %v", gotSa, tt.wantSa)
			}
		})
	}
}

func TestAddStartEnd(t *testing.T) {
	type args struct {
		s string
	}
	tests := []struct {
		name    string
		args    args
		wantSv  string
		wantErr bool
	}{
		{
			name: "Negative Blank input",
			args: args{
				s: "",
			},
			wantErr: true,
		},
		{
			name: "Positive in Short String",
			args: args{
				s: "Hare Krishna",
			},
			wantSv: "~|Hare Krishna|~",
		},
		{
			name: "Positive in Longer String",
			args: args{
				s: "Hare Krishna|Hare Ram",
			},
			wantSv: "~|Hare Krishna|Hare Ram|~",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotSv, err := AddStartEnd(tt.args.s)
			if (err != nil) != tt.wantErr {
				t.Errorf("AddStartEnd() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if gotSv != tt.wantSv {
				t.Errorf("AddStartEnd() = %v, want %v", gotSv, tt.wantSv)
			}
		})
	}
}

func TestRemoveStartEnd(t *testing.T) {
	type args struct {
		s string
	}
	tests := []struct {
		name    string
		args    args
		wantSv  string
		wantErr bool
	}{
		{
			name: "Negative Blank input",
			args: args{
				s: "",
			},
			wantErr: true,
		},
		{
			name: "Positive in Short String",
			args: args{
				s: "~|Hare Krishna|~",
			},
			wantSv: "Hare Krishna",
		},
		{
			name: "Positive in Longer String",
			args: args{
				s: "~|Hare Krishna|Hare Ram|~",
			},
			wantSv: "Hare Krishna|Hare Ram",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotSv, err := RemoveStartEnd(tt.args.s)
			if (err != nil) != tt.wantErr {
				t.Errorf("RemoveStartEnd() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if gotSv != tt.wantSv {
				t.Errorf("RemoveStartEnd() = %v, want %v", gotSv, tt.wantSv)
			}
		})
	}
}
