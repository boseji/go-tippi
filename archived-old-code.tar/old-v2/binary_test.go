// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package tppi

import (
	"bytes"
	"fmt"
	"reflect"
	"testing"
)

func TestToBinary(t *testing.T) {
	type args struct {
		arg          any
		littleEndian bool
	}
	tests := []struct {
		name    string
		args    args
		wantBuf *bytes.Buffer
		wantErr bool
	}{
		{
			name: "Normal conversion of a uint32 variable",
			args: args{
				arg:          uint32(0x3508),
				littleEndian: true,
			},
			wantBuf: bytes.NewBuffer([]byte{
				0x08, 0x35, 0x00, 0x00,
			}),
		},
		{
			name: "Normal conversion of a float64 variable",
			args: args{
				arg:          float64(10.34e15),
				littleEndian: true,
			},
			wantBuf: bytes.NewBuffer([]byte{
				0, 32, 125, 109, 22, 94, 66, 67,
			}),
		},
		{
			name: "Negative for string variable",
			args: args{
				arg:          "Testing String",
				littleEndian: true,
			},
			wantBuf: bytes.NewBuffer([]byte{}),
			wantErr: true,
		},
		{
			name: "Negative Struct",
			args: args{
				arg: struct {
					s string
				}{},
				littleEndian: true,
			},
			wantBuf: bytes.NewBuffer([]byte{}),
			wantErr: true,
		},
		{
			name: "Negative Map",
			args: args{
				arg:          map[int][]byte{},
				littleEndian: true,
			},
			wantBuf: bytes.NewBuffer([]byte{}),
			wantErr: true,
		},
		{
			name: "Normal conversion of a uint32 variable in bigEndian",
			args: args{
				arg:          uint32(0x3508),
				littleEndian: false,
			},
			wantBuf: bytes.NewBuffer([]byte{
				0x00, 0x00, 0x35, 0x08,
			}),
		},
		{
			name: "Normal conversion of a []byte variable",
			args: args{
				arg:          []byte{0x35, 0x08},
				littleEndian: true,
			},
			wantBuf: bytes.NewBuffer([]byte{0x35, 0x08}),
		},
		{
			name: "Normal conversion of a []uint32 variable",
			args: args{
				arg:          []uint32{0x35, 0x08},
				littleEndian: true,
			},
			wantBuf: bytes.NewBuffer([]byte{
				0x35, 0x00, 0x00, 0x00,
				0x08, 0x00, 0x00, 0x00,
			}),
		},
		{
			name: "Normal conversion of a []uint16 variable in BigEndian",
			args: args{
				arg:          []uint16{0x35, 0x08},
				littleEndian: false,
			},
			wantBuf: bytes.NewBuffer([]byte{
				0x00, 0x35,
				0x00, 0x08,
			}),
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			buf := new(bytes.Buffer)
			err := ToBinary(tt.args.arg, tt.args.littleEndian,
				buf)
			if (err != nil) != tt.wantErr {
				t.Errorf("ToBinary() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(buf, tt.wantBuf) && !tt.wantErr {
				t.Errorf("ToBinary() = %v, want %v",
					buf.Bytes(), tt.wantBuf.Bytes())
			}
		})
	}
}

func TestFromBinary(t *testing.T) {
	type args struct {
		arg          any
		buf          *bytes.Buffer
		littleEndian bool
	}
	tests := []struct {
		name     string
		args     args
		wantErr  bool
		validate func(any) error
	}{
		{
			name: "Normal conversion of a uint32 variable",
			args: args{
				arg: new(uint32),
				buf: bytes.NewBuffer([]byte{
					0x08, 0x35, 0x00, 0x00,
				}),
				littleEndian: true,
			},
			validate: func(a any) error {
				v, ok := a.(*uint32)
				if !ok {
					return fmt.Errorf("type Error")
				}
				val := *v
				want := uint32(0x3508)
				if val != want {
					return fmt.Errorf("value error got %v want %v", val, want)
				}
				return nil
			},
		},
		{
			name: "Normal conversion of a float64 variable",
			args: args{
				arg: new(float64),
				buf: bytes.NewBuffer([]byte{
					0, 32, 125, 109, 22, 94, 66, 67,
				}),
				littleEndian: true,
			},
			validate: func(a any) error {
				v, ok := a.(*float64)
				if !ok {
					return fmt.Errorf("type Error")
				}
				val := *v
				want := float64(10.34e15)
				if val != want {
					return fmt.Errorf("value error got %v want %v", val, want)
				}
				return nil
			},
		},
		{
			name: "Negative for string variable",
			args: args{
				arg:          new(string),
				buf:          bytes.NewBuffer([]byte{}),
				littleEndian: true,
			},
			wantErr: true,
		},
		{
			name: "Negative Struct",
			args: args{
				arg: new(struct {
					s string
				}),
				buf:          bytes.NewBuffer([]byte{}),
				littleEndian: true,
			},
			wantErr: true,
		},
		{
			name: "Negative Map",
			args: args{
				arg:          new(map[int][]byte),
				buf:          bytes.NewBuffer([]byte{}),
				littleEndian: true,
			},
			wantErr: true,
		},
		{
			name: "Normal conversion of a uint32 variable in bigEndian",
			args: args{
				arg: new(uint32),
				buf: bytes.NewBuffer([]byte{
					0x00, 0x00, 0x35, 0x08,
				}),
				littleEndian: false,
			},
			validate: func(a any) error {
				v, ok := a.(*uint32)
				if !ok {
					return fmt.Errorf("type Error")
				}
				val := *v
				want := uint32(0x3508)
				if val != want {
					return fmt.Errorf("value error got %v want %v", val, want)
				}
				return nil
			},
		},
		{
			name: "Normal conversion of a []byte variable",
			args: args{
				arg: func() *[]byte {
					v := make([]byte, 2)
					return &v
				}(),
				buf:          bytes.NewBuffer([]byte{0x35, 0x08}),
				littleEndian: true,
			},
			validate: func(a any) error {
				v, ok := a.(*[]byte)
				if !ok {
					return fmt.Errorf("type Error")
				}
				val := *v
				want := []byte{0x35, 0x08}
				if !bytes.Equal(val, want) {
					return fmt.Errorf("value error got %v want %v", val, want)
				}
				return nil
			},
		},
		{
			name: "Normal conversion of a []uint32 variable",
			args: args{
				arg: func() *[]uint32 {
					v := make([]uint32, 2)
					return &v
				}(),
				buf: bytes.NewBuffer([]byte{
					0x35, 0x00, 0x00, 0x00,
					0x08, 0x00, 0x00, 0x00,
				}),
				littleEndian: true,
			},
			validate: func(a any) error {
				v, ok := a.(*[]uint32)
				if !ok {
					return fmt.Errorf("type Error")
				}
				val := *v
				want := []uint32{0x35, 0x08}
				if !reflect.DeepEqual(val, want) {
					return fmt.Errorf("value error got %v want %v", val, want)
				}
				return nil
			},
		},
		{
			name: "Normal conversion of a []uint16 variable in BigEndian",
			args: args{
				arg: func() *[]uint16 {
					v := make([]uint16, 2)
					return &v
				}(),
				buf: bytes.NewBuffer([]byte{
					0x00, 0x35,
					0x00, 0x08,
				}),
				littleEndian: false,
			},
			validate: func(a any) error {
				v, ok := a.(*[]uint16)
				if !ok {
					return fmt.Errorf("type Error")
				}
				val := *v
				want := []uint16{0x35, 0x08}
				if !reflect.DeepEqual(val, want) {
					return fmt.Errorf("value error got %v want %v", val, want)
				}
				return nil
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := FromBinary(tt.args.arg, tt.args.buf, tt.args.littleEndian); (err != nil) != tt.wantErr {
				t.Errorf("FromBinary() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !tt.wantErr {
				if err := tt.validate(tt.args.arg); err != nil {
					t.Errorf("FromBinary() return value error = %v", err)
				}
			}
		})
	}
}
