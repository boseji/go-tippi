// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package tppi

import (
	"fmt"
	"regexp"
	"strings"
)

// Protocol Level Symbol Constants
const (
	SYM_TILDE = "~"
	SYM_PIPE  = "|"
	SYM_START = "~|"
	SYM_END   = "|~"
)

// Protocol Separators
const (
	SEP_CONTENT = SYM_TILDE
	SEP_LINES   = SYM_PIPE
)

// Protocol Regex Filters
const (
	regexp_STUFF_PIPE     = `(?m)[\|]`
	regexp_STUFF_TILDE    = `(?m)[~]`
	replace_STUFF_PIPE    = `\x7C`
	replace_STUFF_TILDE   = `\x2D`
	regexp_UN_STUFF_PIPE  = `(?m)(\\x7C)`
	regexp_UN_STUFF_TILDE = `(?m)(\\x2D)`
	regexp_Stuffed        = `(?m)[\|~]`
)

// Stuff implements the Rules method to adds necessary
// protocol detection guards on a supplied content for TPPI protocol.
func Stuff(s string) (sv string, err error) {
	if len(s) == 0 {
		err = fmt.Errorf("no supplied parts to stuff")
		return
	}
	sv = strings.Clone(s)
	// Pipe Regex
	re := regexp.MustCompile(regexp_STUFF_PIPE)
	sv = re.ReplaceAllString(sv, replace_STUFF_PIPE)
	// Tilde Regex
	re = regexp.MustCompile(regexp_STUFF_TILDE)
	sv = re.ReplaceAllString(sv, replace_STUFF_TILDE)
	return
}

// UnStuff implements the Rules method to remove the protocol detection guards
// on the supplied content for TPPI protocol.
func UnStuff(s string) (sv string, err error) {
	if len(s) == 0 {
		err = fmt.Errorf("no supplied parts to un-stuff")
		return
	}
	sv = strings.Clone(s)
	// Pipe Regex
	re := regexp.MustCompile(regexp_UN_STUFF_PIPE)
	sv = re.ReplaceAllString(sv, SYM_PIPE)
	// Tilde Regex
	re = regexp.MustCompile(regexp_UN_STUFF_TILDE)
	sv = re.ReplaceAllString(sv, SYM_TILDE)
	return
}

// NeedsStuff reports if the supplied string contains Symbols that needs
// stuffing as per TPPI protocol.
// Returns True only if the has Symbols that needs stuffing.
func NeedsStuff(s string) bool {
	re := regexp.MustCompile(regexp_Stuffed)
	sa := re.FindAllString(s, -1)
	return (len(sa) > 0)
}

// JoinLines implements the CollectionRule method to help
// join multiple Lines together for TPPI protocol.
func JoinLines(sa ...string) (s string, err error) {
	if len(sa) == 0 {
		err = fmt.Errorf("no supplied parts to join lines")
		return
	}
	s = strings.Join(sa, SEP_LINES)
	return
}

// JoinContents implements the CollectionRule method to help join the contents
// into a single line for TPPI protocol.
func JoinContents(sa ...string) (s string, err error) {
	if len(sa) == 0 {
		err = fmt.Errorf("no supplied parts to join content")
		return
	}
	s = strings.Join(sa, SEP_CONTENT)
	return
}

// SplitLines implements the SplittingRule method to help break the provided
// packet into multiple lines for TPPI protocol.
func SplitLines(s string) (sa []string, err error) {
	if len(s) == 0 {
		err = fmt.Errorf("no string supplied to split into lines")
		return
	}
	sa = strings.Split(s, SEP_LINES)
	return
}

// SplitContents implements tge SplittingRule method to help break the
// provided line into its contents for TPPI protocol.
func SplitContents(s string) (sa []string, err error) {
	if len(s) == 0 {
		err = fmt.Errorf("no string supplied to split into content")
		return
	}
	sa = strings.Split(s, SEP_CONTENT)
	return
}

// AddStartEnd implements the Rules method that helps to add the framing
// for the protocol packet for TPPI protocol.
func AddStartEnd(s string) (sv string, err error) {
	if len(s) == 0 {
		err = fmt.Errorf("no string supplied to add start and end")
		return
	}
	sv = SYM_START + s + SYM_END
	return
}

// RemoveStartEnd implements the Rules method that helps to remove the framing
// for the protocol packet for TPPI protocol.
func RemoveStartEnd(s string) (sv string, err error) {
	if len(s) == 0 {
		err = fmt.Errorf("no string supplied to remove start and end")
		return
	}
	sv = strings.Clone(s)
	if strings.Contains(sv, SYM_START) {
		sv = strings.ReplaceAll(s, SYM_START, "")
	}
	if strings.Contains(sv, SYM_END) {
		sv = strings.ReplaceAll(sv, SYM_END, "")
	}
	return
}
