// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package data

import (
	"reflect"
	"strings"
	"testing"
)

func Test_ByteSlice(t *testing.T) {
	tests := []struct {
		name  string
		value ByteSlice
		wantS string
		wantT string
	}{
		{
			name:  "ByteSlice representation1",
			value: NewByteSlice([]byte{1, 2, 3}),
			wantS: "[1 2 3]",
			wantT: byteSliceTypeSignature,
		},
		{
			name:  "Int representation2",
			value: NewByteSlice([]byte{}),
			wantS: "[]",
			wantT: byteSliceTypeSignature,
		},
		{
			name:  "Int representation3",
			value: NewByteSlice(nil),
			wantS: "[]",
			wantT: byteSliceTypeSignature,
		},
		{
			name:  "ByteSlice representation1",
			value: NewByteSlice([]byte{0x3A, 0xF1, 0x41}),
			wantS: "[3a f1 41]",
			wantT: byteSliceTypeSignature,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotS := tt.value.String()
			gotT := tt.value.Type()
			if strings.Compare(gotS, tt.wantS) != 0 {
				t.Errorf("error in String got %v expected %v", gotS, tt.wantS)
				return
			}
			if strings.Compare(gotT, tt.wantT) != 0 {
				t.Errorf("error in Type got %v expected %v", gotT, tt.wantT)
			}
		})
	}
	tests2 := []struct {
		name    string
		argType string
		argTag  string
		argData string
		want    ByteSlice
		wantErr bool
	}{
		{
			name:    "ByteSlice recovery1",
			argType: byteSliceTypeSignature,
			argTag:  "",
			argData: "[1 2 3]",
			want:    NewByteSlice([]byte{1, 2, 3}),
		},
		{
			name:    "ByteSlice recovery2",
			argType: byteSliceTypeSignature,
			argTag:  "temp",
			argData: "[]",
			want:    NewByteSlice([]byte{}).SetTag("temp"),
		},
		{
			name:    "ByteSlice recovery3",
			argType: byteSliceTypeSignature,
			argTag:  "ID",
			argData: "[3a f1 41]",
			want:    NewByteSlice([]byte{0x3A, 0xF1, 0x41}).SetTag("ID"),
		},
		{
			name:    "ByteSlice recovery Error1",
			argType: "k",
			argTag:  "",
			argData: "[1 2 3]",
			wantErr: true,
		},
		{
			name:    "ByteSlice recovery Error2",
			argType: byteSliceTypeSignature,
			argTag:  "",
			argData: "[",
			wantErr: true,
		},
		{
			name:    "ByteSlice recovery Error3",
			argType: byteSliceTypeSignature,
			argTag:  "",
			argData: "[-3 3]",
			wantErr: true,
		},
		{
			name:    "ByteSlice recovery Error4",
			argType: byteSliceTypeSignature,
			argTag:  "",
			argData: "[ 3 3]",
			wantErr: true,
		},
		{
			name:    "ByteSlice recovery Error5",
			argType: byteSliceTypeSignature,
			argTag:  "",
			argData: "[3 3 fff]",
			wantErr: true,
		},
	}
	for _, tt := range tests2 {
		t.Run(tt.name, func(t *testing.T) {
			b := NewByteSlice([]byte{})
			err := b.Recover(tt.argType, tt.argTag, tt.argData)
			if (err != nil) != tt.wantErr {
				t.Errorf("failed to Recover() error - %v want error %v",
					err, tt.wantErr)
				return
			}
			if !tt.wantErr && !reflect.DeepEqual(b, tt.want) {
				t.Errorf("value error got %#v expected %#v", b, tt.want)
			}
		})
	}
}
