// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package data

import (
	"fmt"
	"strings"
)

type ByteSlice struct {
	BS  []byte
	Tag string
}

const (
	byteSliceTypeSignature = "BS0"
	byteSliceMemberFormat  = "%x"
	byteSlicePrefix        = "["
	byteSliceSuffix        = "]"
	byteSliceSeparator     = " "
)

func (b ByteSlice) Type() string {
	return byteSliceTypeSignature
}

func (b ByteSlice) String() string {
	if len(b.BS) == 0 {
		return byteSlicePrefix + byteSliceSuffix
	}
	sa := make([]string, 0, len(b.BS))
	for _, i := range b.BS {
		sa = append(sa, fmt.Sprintf(byteSliceMemberFormat, i))
	}
	return byteSlicePrefix + strings.Join(sa, byteSliceSeparator) +
		byteSliceSuffix
}

func (b *ByteSlice) Recover(Type, Tag, Data string) error {
	if Type != byteSliceTypeSignature {
		return fmt.Errorf("invalid ByteSlice type")
	}
	b.Tag = Tag
	if !strings.HasPrefix(Data, byteSlicePrefix) ||
		!strings.HasSuffix(Data, byteSliceSuffix) {
		return fmt.Errorf("wrong ByteSlice format start or end")
	}
	s, _ := strings.CutPrefix(Data, byteSlicePrefix)
	s, _ = strings.CutSuffix(s, byteSliceSuffix)
	if len(s) == 0 {
		b.BS = []byte{}
		return nil
	}
	sa := strings.Split(s, byteSliceSeparator)
	val := make([]byte, len(sa))
	for iter, si := range sa {
		_, err := fmt.Sscanf(si, byteSliceMemberFormat, &val[iter])
		if err != nil {
			return fmt.Errorf("failed to recover ByteSlice due to %v at %v",
				err, iter)
		}
	}
	b.BS = val
	return nil
}

func (b ByteSlice) SetTag(s string) ByteSlice {
	b.Tag = s
	return b
}

func NewByteSlice(b []byte) ByteSlice {
	return ByteSlice{b, ""}
}
