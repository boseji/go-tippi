// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package data

import (
	"reflect"
	"strings"
	"testing"
)

func Test_Int(t *testing.T) {
	tests := []struct {
		name  string
		value Int
		wantS string
		wantT string
	}{
		{
			name:  "Int representation1",
			value: NewInt(5),
			wantS: "5",
			wantT: intTypeSignature,
		},
		{
			name:  "Int representation2",
			value: NewInt(0x3508A),
			wantS: "3508a",
			wantT: intTypeSignature,
		},
		{
			name:  "Int representation3",
			value: NewInt(-1729),
			wantS: "-6c1",
			wantT: intTypeSignature,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotS := tt.value.String()
			gotT := tt.value.Type()
			if strings.Compare(gotS, tt.wantS) != 0 {
				t.Errorf("error in String got %v expected %v", gotS, tt.wantS)
				return
			}
			if strings.Compare(gotT, tt.wantT) != 0 {
				t.Errorf("error in Type got %v expected %v", gotT, tt.wantT)
			}
		})
	}
	tests2 := []struct {
		name    string
		argType string
		argTag  string
		argData string
		want    Int
		wantErr bool
	}{
		{
			name:    "Int recovery1",
			argType: intTypeSignature,
			argTag:  "",
			argData: "5",
			want:    NewInt(5),
		},
		{
			name:    "Int recovery2",
			argType: intTypeSignature,
			argTag:  "temp",
			argData: "3508a",
			want:    NewInt(0x3508A).SetTag("temp"),
		},
		{
			name:    "Int recovery3",
			argType: intTypeSignature,
			argTag:  "level",
			argData: "-6c1",
			want:    NewInt(-1729).SetTag("level"),
		},
		{
			name:    "Int recovery Error1",
			argType: "k",
			argTag:  "",
			argData: "3508a",
			wantErr: true,
		},
		{
			name:    "Int recovery Error2",
			argType: intTypeSignature,
			argTag:  "",
			argData: "=2p1",
			wantErr: true,
		},
		{
			name:    "Int recovery Error3",
			argType: intTypeSignature,
			argTag:  "",
			argData: "ffffffffffffffff",
			wantErr: true,
		},
	}
	for _, tt := range tests2 {
		t.Run(tt.name, func(t *testing.T) {
			i := NewInt(0)
			err := i.Recover(tt.argType, tt.argTag, tt.argData)
			if (err != nil) != tt.wantErr {
				t.Errorf("failed to Recover() error - %v want error %v",
					err, tt.wantErr)
				return
			}
			if !tt.wantErr && !reflect.DeepEqual(i, tt.want) {
				t.Errorf("value error got %#v expected %#v", i, tt.want)
			}
		})
	}
}
