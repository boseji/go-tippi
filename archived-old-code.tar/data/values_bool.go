// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package data

import "fmt"

type Bool struct {
	bool
	Tag string
}

const (
	boolTypeSignature = "B"
	boolDataTrue      = "1"
	boolDataFalse     = "0"
)

func (b Bool) Type() string {
	return boolTypeSignature
}

func (b Bool) String() string {
	if b.bool {
		return boolDataTrue
	}
	return boolDataFalse
}

func (b *Bool) Recover(Type, Tag, Data string) error {
	if Type != boolTypeSignature {
		return fmt.Errorf("invalid bool type")
	}
	b.Tag = Tag
	if Data == boolDataTrue {
		b.bool = true
	} else if Data == boolDataFalse {
		b.bool = false
	} else {
		return fmt.Errorf("invalid bool data")
	}
	return nil
}

func (b Bool) SetTag(s string) Bool {
	b.Tag = s
	return b
}

func NewBool(b bool) Bool {
	return Bool{b, ""}
}
