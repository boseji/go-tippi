// Copyright (C) 2024 Abhijit Bose (aka. Boseji). All rights reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX short identifier: Apache-2.0

package data

import (
	"reflect"
	"strings"
	"testing"
)

func Test_Bool(t *testing.T) {
	tests := []struct {
		name  string
		value Bool
		wantS string
		wantT string
	}{
		{
			name:  "Bool representation1",
			value: Bool{true, ""},
			wantS: "1",
			wantT: "B",
		},
		{
			name:  "Bool representation2",
			value: Bool{false, ""},
			wantS: "0",
			wantT: "B",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotS := tt.value.String()
			gotT := tt.value.Type()
			if strings.Compare(gotS, tt.wantS) != 0 {
				t.Errorf("error in String got %v expected %v", gotS, tt.wantS)
				return
			}
			if strings.Compare(gotT, tt.wantT) != 0 {
				t.Errorf("error in Type got %v expected %v", gotT, tt.wantT)
			}
		})
	}
	tests2 := []struct {
		name    string
		argType string
		argTag  string
		argData string
		want    Bool
		wantErr bool
	}{
		{
			name:    "Bool recovery1",
			argType: boolTypeSignature,
			argTag:  "",
			argData: "1",
			want:    NewBool(true),
		},
		{
			name:    "Bool recovery2",
			argType: boolTypeSignature,
			argTag:  "valBit",
			argData: "0",
			want:    NewBool(false).SetTag("valBit"),
		},
		{
			name:    "Bool recovery Error1",
			argType: "k",
			argTag:  "valBit",
			argData: "0",
			wantErr: true,
		},
		{
			name:    "Bool recovery Error2",
			argType: boolTypeSignature,
			argTag:  "valBit",
			argData: "true",
			wantErr: true,
		},
	}
	for _, tt := range tests2 {
		t.Run(tt.name, func(t *testing.T) {
			b := NewBool(false)
			err := b.Recover(tt.argType, tt.argTag, tt.argData)
			if (err != nil) != tt.wantErr {
				t.Errorf("failed to Recover() error - %v want error %v",
					err, tt.wantErr)
				return
			}
			if !tt.wantErr && !reflect.DeepEqual(b, tt.want) {
				t.Errorf("value error got %#v expected %#v", b, tt.want)
			}
		})
	}
}
